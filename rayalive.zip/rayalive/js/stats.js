import { db } from "./firebase.js";
import {
  ref,
  runTransaction,
  get
} from "https://www.gstatic.com/firebasejs/10.13.0/firebase-database.js";


// ============================================================
// REGISTRAR RESULTADO
// ============================================================
//
// Cada jugador modifica ÚNICAMENTE:
// users/{su propio UID}
//
// outcome:
// "win"
// "loss"
// "draw"
//

export async function recordMyResult(userId, outcome) {

  if (!userId) {
    throw new Error("userId no válido");
  }

  if (!["win", "loss", "draw"].includes(outcome)) {
    throw new Error("Resultado no válido: " + outcome);
  }


  const userRef =
    ref(db, "users/" + userId);


  const result =
    await runTransaction(
      userRef,
      (user) => {

        if (!user) {
          return user;
        }


        // Aseguramos que todos los campos existan.

        user.wins =
          Number(user.wins) || 0;

        user.losses =
          Number(user.losses) || 0;

        user.draws =
          Number(user.draws) || 0;

        user.streak =
          Number(user.streak) || 0;

        user.bestStreak =
          Number(user.bestStreak) || 0;


        // ======================================================
        // VICTORIA
        // ======================================================

        if (outcome === "win") {

          user.wins += 1;

          user.streak += 1;


          if (
            user.streak >
            user.bestStreak
          ) {

            user.bestStreak =
              user.streak;

          }

        }


        // ======================================================
        // DERROTA
        // ======================================================

        else if (outcome === "loss") {

          user.losses += 1;

          user.streak = 0;

        }


        // ======================================================
        // EMPATE
        // ======================================================

        else if (outcome === "draw") {

          user.draws += 1;

          // El empate NO rompe la racha.
          // Si quieres que el empate la rompa,
          // cambia esto a:
          //
          // user.streak = 0;

        }


        return user;

      }
    );


  if (!result.committed) {

    return null;

  }


  const value =
    result.snapshot.val();


  return normalizeStats(value);

}


// ============================================================
// NORMALIZAR ESTADÍSTICAS
// ============================================================

function normalizeStats(value = {}) {

  return {

    wins:
      Number(value.wins) || 0,

    losses:
      Number(value.losses) || 0,

    draws:
      Number(value.draws) || 0,

    streak:
      Number(value.streak) || 0,

    bestStreak:
      Number(value.bestStreak) || 0

  };

}


// ============================================================
// OBTENER RACHA
// ============================================================

export async function getStreak(id) {

  if (!id) {
    return 0;
  }


  const snap =
    await get(
      ref(
        db,
        "users/" +
        id +
        "/streak"
      )
    );


  if (!snap.exists()) {
    return 0;
  }


  return Number(
    snap.val()
  ) || 0;

}


// ============================================================
// RESET DE RACHA
// ============================================================
//
// Se utiliza cuando el jugador abandona una partida.
// NO cuenta como derrota.
//

export async function resetMyStreak(
  userId
) {

  if (!userId) {
    return;
  }


  const userRef =
    ref(
      db,
      "users/" + userId
    );


  await runTransaction(
    userRef,
    (user) => {

      if (!user) {
        return user;
      }


      user.streak = 0;


      return user;

    }
  );

}


// ============================================================
// OBTENER TODAS LAS ESTADÍSTICAS
// ============================================================

export async function getUserStats(
  id
) {

  if (!id) {

    return {

      wins: 0,
      losses: 0,
      draws: 0,
      streak: 0,
      bestStreak: 0

    };

  }


  const snap =
    await get(
      ref(
        db,
        "users/" + id
      )
    );


  if (!snap.exists()) {

    return {

      wins: 0,
      losses: 0,
      draws: 0,
      streak: 0,
      bestStreak: 0

    };

  }


  return normalizeStats(
    snap.val()
  );

}


// ============================================================
// RANKING GLOBAL
// ============================================================

export async function getTopStreaks(
  limit = 50
) {

  const snap =
    await get(
      ref(
        db,
        "users"
      )
    );


  if (!snap.exists()) {
    return [];
  }


  const data =
    snap.val();


  const users =
    Object.entries(data)

      .map(
        ([id, user]) => {

          if (
            !user ||
            !user.name
          ) {

            return null;

          }


          return {

            id,

            name:
              user.name,

            wins:
              Number(user.wins) || 0,

            losses:
              Number(user.losses) || 0,

            draws:
              Number(user.draws) || 0,

            streak:
              Number(user.streak) || 0,

            bestStreak:
              Number(user.bestStreak) || 0

          };

        }
      )

      .filter(Boolean);


  users.sort(
    (a, b) => {

      // Primero racha actual

      const streakDifference =
        b.streak -
        a.streak;


      if (
        streakDifference !== 0
      ) {

        return streakDifference;

      }


      // Después mejor racha

      const bestDifference =
        b.bestStreak -
        a.bestStreak;


      if (
        bestDifference !== 0
      ) {

        return bestDifference;

      }


      // Después victorias

      return (
        b.wins -
        a.wins
      );

    }
  );


  return users.slice(
    0,
    limit
  );

}