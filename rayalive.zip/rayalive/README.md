# RayaLive

Juego de tres en raya (tic-tac-toe) multijugador en tiempo real, hecho con
HTML/CSS/JS puro (sin frameworks ni build) y Firebase (Realtime Database +
Authentication).

## ⚠️ Si vienes de una versión anterior: vuelve a publicar las reglas

Esta versión corrige un bug real y cambia `database.rules.json`. Tienes
que volver a pegar el archivo nuevo en Firebase (Realtime Database →
Reglas → pegar → Publicar), si no, seguirás viendo el error.

**El bug que tenías**: al ganar salía `permission_denied` en una
transacción sobre `/users/{uid}`. La causa: el código anterior hacía que
**un solo jugador** actualizara la racha de **los dos** jugadores a la
vez, pero la regla de seguridad dice "solo puedes escribir tu propio
nodo" — y esa regla está bien, es la que te protege de que cualquiera
pueda falsificar la racha de otro. El error era del diseño del código,
no de la regla. Ahora cada jugador actualiza únicamente su propio nodo
(`js/stats.js`, función `recordMyResult`), así que nunca intenta escribir
en datos ajenos.

De paso, las reglas también tenían otro fallo que te habría afectado
tarde o temprano: te faltaba permiso de **lectura a nivel de todo
`/users`** (solo lo tenías por usuario individual), necesario tanto para
el panel admin como para el nuevo Ranking. Ya está añadido.

## ⚠️ Vuelve a publicar las reglas (nuevo cambio)

`database.rules.json` ha cambiado otra vez: añade el nodo `/usernames`
para que los nombres sean únicos de verdad. Pégalo de nuevo en Firebase
(Realtime Database → Reglas → pegar → Publicar) o el registro de
nombres dará error de permisos.

## Nombres de usuario únicos

Ya no puede haber dos jugadores con el mismo nombre (sin distinguir
mayúsculas ni acentos: "Pedro", "pedro" y "PEDRO" cuentan como el
mismo). Funciona así:

- Hay un nodo `/usernames/{nombre-normalizado}` en Firebase que actúa
  como índice: cada clave solo puede apuntar al UID de quien la reservó.
- La regla de seguridad impide que nadie robe el nombre de otra
  persona escribiendo directamente en la base de datos — no es solo
  una comprobación del cliente, está reforzada en el servidor.
- Si intentas guardar un nombre que ya tiene otra persona, sale el
  aviso "Ese nombre ya lo está usando otra persona" en el propio
  formulario, sin cerrar el modal.
- Si cambias de nombre, se libera automáticamente tu reserva anterior
  para que otra persona pueda usarla.
- Si ya jugabas antes de esta versión, la app intenta reservar tu
  nombre actual en segundo plano la primera vez que entres; si por mala
  suerte alguien ya se adelantó con ese mismo nombre, no pasa nada
  grave — simplemente no queda reservado a tu favor y podrías, en
  teoría, coincidir con otra persona hasta que cambies de nombre tú.

## Nombre en rojo, visible para todo el mundo

En `js/firebase-config.js` hay una constante nueva:

```js
export const VIP_NAME = "CAMBIA_ESTO_POR_TU_NOMBRE";
```

Cambia ese valor por tu nombre exacto de jugador (no distingue
mayúsculas ni acentos). A partir de ahí, tu nombre sale en **rojo**
para **todo el mundo**, no solo para ti, en:

- Los tableros de partida (tuyo y del rival).
- La lista del Ranking.

Es una comparación de texto (`js/vip.js`), no un permiso especial de
Firebase: cualquiera que use exactamente ese nombre también lo vería en
rojo — pero como los nombres ahora son únicos, solo puede haber una
persona con ese nombre a la vez.

## Logros

Botón **Logros** en el menú. De momento hay 3, con nombre propio y
condición concreta (no son contadores numéricos):

1. **Primera victoria** — gana tu primera partida online.
2. **En racha** — consigue 3 victorias seguidas.
3. **Jugador dedicado** — juega 10 partidas online.

Para añadir más, solo hay que meter un objeto nuevo en el array
`ACHIEVEMENTS` de `js/achievements.js` con su propia condición
(`check: (v) => ...`) — no hace falta tocar Firebase ni las reglas de
seguridad, todo se calcula al vuelo a partir de `wins`, `losses`,
`draws` y `bestStreak`.

Cuando desbloqueas uno nuevo (justo al terminar una partida online), sale
una notificación arriba a la derecha, estilo Google Play Games, que se
oculta sola a los pocos segundos. Si una partida desbloquea varios a la
vez, se muestran en cola, una detrás de otra.

Solo cuentan las partidas online (contra otra persona), no contra la IA
— igual que con la racha, para que no se pueda inflar jugando en fácil.

## Abandonar una partida a medias

Si sales con "Salir al menú" **mientras la partida sigue en curso** (no
ha terminado todavía), pierdes tu racha actual — se resetea a 0, aunque
no cuenta como derrota formal (no suma a tu contador de derrotas, solo
te quita la racha). Al rival le sale un aviso de que te has ido y **no**
recibe ninguna victoria ni racha por ello: la sala simplemente se borra
y ambos volvéis al menú.

Esto no aplica si sales después de que la partida ya haya terminado
normalmente (ganada, perdida o empatada): ahí las estadísticas ya se
aplicaron de forma correcta al terminar, y el botón de salir del propio
modal de resultado no toca la racha de nuevo.

## Administración: todo desde Firebase, sin panel propio

Ya no hay `admin.html`. Todo lo que antes hacía el panel (ver salas y
usuarios, banear, desbanear, borrar salas) se hace directamente desde
la consola de Firebase o el CLI de Firebase — más seguro que un panel
propio, porque entrar ahí requiere tu cuenta de Google con permisos
sobre el proyecto, no una contraseña metida en el código JavaScript.

### Por qué esto es más seguro que antes

Las reglas de seguridad (`database.rules.json`) solo se aplican a las
peticiones que llegan desde el SDK de Firebase que usan los jugadores.
La consola web de Firebase y el CLI (tras `firebase login` con tu
cuenta) usan acceso de administrador del proyecto y se saltan esas
reglas por completo — por eso, aunque la regla de `/bans` diga
`.write: false` para todo el mundo, tú sí puedes escribir ahí desde la
consola o el CLI. No hace falta ningún UID especial ni contraseña.

### Ver todas las salas y usuarios

Consola: [console.firebase.google.com](https://console.firebase.google.com/)
→ tu proyecto → Realtime Database → pestaña Datos.

CLI (`npm install -g firebase-tools`, luego `firebase login` una vez):
```bash
firebase database:get /rooms --project tresenrayaa-9f327
firebase database:get /users --project tresenrayaa-9f327
```

### Encontrar el UID de un jugador

En la consola, abre `/users` y despliega los nodos: cada hijo es un
UID, y dentro tiene su `name`. Busca el que coincida con el nombre que
quieres banear y copia esa clave.

### Banear a alguien

Por consola: en `/bans`, crea un nodo con clave = el UID del jugador, y
dentro estos campos: `reason` (texto del motivo), `permanent` (`true`
o `false`), `until` (si no es permanente: la hora exacta en que expira,
en milisegundos desde 1970 — puedes calcularla con
`Date.now() + horas*3600000` en la consola del navegador; si es
permanente, `null`), y `bannedAt` (el momento actual en milisegundos,
solo informativo).

Por CLI: crea un archivo `ban.json`, por ejemplo para un baneo
permanente:
```json
{
  "reason": "Insultos en el chat",
  "permanent": true,
  "until": null,
  "bannedAt": 1735689600000
}
```
Y súbelo con:
```bash
firebase database:set /bans/UID_DEL_JUGADOR ban.json --project tresenrayaa-9f327
```

En cuanto ese nodo existe, la persona baneada lo detecta en tiempo real
(sin recargar): le sale una pantalla completa con "BANEADO", el motivo
y la duración. Si estaba jugando en ese momento, se le saca de la
partida al instante y a su rival le sale "El jugador ha sido
baneado.". Si el baneo es temporal, en cuanto expira su página se
recarga sola.

### Desbanear

Por consola: abre `/bans/{uid}` y bórralo. Por CLI:
```bash
firebase database:remove /bans/UID_DEL_JUGADOR --project tresenrayaa-9f327
```

### Borrar una sala

Por consola: abre `/rooms/{código}` y bórralo. Por CLI:
```bash
firebase database:remove /rooms/CODIGO --project tresenrayaa-9f327
```

## Ver estadísticas propias y de otros jugadores

- Al pulsar tu nombre arriba a la derecha (donde cambias de nombre),
  ahora también ves tus estadísticas debajo del formulario: victorias,
  derrotas, empates, partidas jugadas, racha actual y mejor racha.
  Hay un botón **Cerrar** para salir sin cambiar nada (solo aparece si
  ya tienes un nombre puesto; la primera vez que entras, tienes que
  elegir uno antes de poder cerrar el formulario).
- Dentro de una partida, el nombre de cada jugador (el tuyo y el del
  rival) es clicable: al pulsarlo se abre una ventana con sus
  estadísticas, en modo solo lectura (no puedes cambiarle el nombre a
  nadie más, solo verlas).
- Contra la IA, tu propio nombre sigue siendo clicable (tus
  estadísticas reales); el nombre de la IA no lo es, porque no tiene
  estadísticas guardadas en Firebase.

## Ranking y racha visible en el menú

- Botón **🏆 Ranking** arriba a la derecha: leaderboard con los jugadores
  que tienen racha activa, ordenados de mayor a menor (empate a racha
  desempata por `bestStreak`). Se marca tu propia fila.
- En el menú principal ves tu racha actual con 🔥 en todo momento.
- Las partidas contra la IA **no cuentan** para la racha ni el ranking
  (si contaran, cualquiera podría inflar su racha jugando en "Fácil").

## Autenticación anónima (obligatoria)

A partir de esta versión, la app inicia sesión anónima con Firebase Auth
automáticamente (el usuario no ve ni rellena nada) para poder aplicar
reglas de seguridad de verdad. **Si no activas esto, la app no funcionará
y verás un error de conexión al abrirla:**

1. Consola de Firebase → tu proyecto → **Authentication**.
2. Pestaña **Sign-in method** (Método de acceso).
3. Activa el proveedor **Anónimo**.

Nada más. `js/firebase-config.js` ya tiene tus credenciales, no hay que
tocar nada ahí salvo `VIP_NAME` si quieres el nombre en rojo.

## Qué incluye esta versión

- **Buscar partida**: te empareja al momento con otra persona que también
  esté buscando, sin necesidad de código.
- **Unirme con código** / **Crear sala** / **Jugar contra la IA**: igual
  que antes.
- **Temporizador de 20s por turno** (constante `TURN_SECONDS` en
  `js/rooms.js`). Si se agota, el turno pasa solo al rival.
- **Modal de resultado**: al terminar la partida sale una ventana con
  "¡Has ganado!" o "Has perdido" en rojo (empate en gris), con un botón
  de revancha.
  - Online: si pides revancha, el rival ve un aviso con **Aceptar** /
    **Rechazar**. Si acepta, la partida se reinicia para los dos. Si
    rechaza, ambos vuelven al menú y la sala se borra.
  - Contra la IA: revancha = partida nueva al momento.
- **Sistema de rachas**: cada victoria consecutiva suma 1 a tu racha;
  perder la resetea a 0. Cuando te enfrentas a alguien, ves la racha
  de cada jugador encima del tablero (si es mayor que 0). También se
  guardan `wins`, `losses`, `draws` y `bestStreak` por usuario en
  Firebase, por si quieres mostrarlos en algún futuro ranking.
- **Salas que se borran solas**:
  - Si sales de una partida ("Salir al menú"), se borra.
  - Si cancelas una sala de espera, se borra.
  - Si se rechaza una revancha, se borra.
  - Si creas una sala y **cierras la pestaña mientras nadie se ha
    unido**, Firebase la borra sola (usando `onDisconnect`, sin
    necesidad de ningún backend tuyo).
  - Limitación honesta: si una partida ya está en marcha (dos jugadores
    dentro) y una persona simplemente cierra la pestaña sin pulsar
    "Salir", esa sala se queda en la base de datos hasta que alguien
    la borre a mano desde la consola de Firebase. Borrarla
    automáticamente requeriría una Cloud Function con un cron, que queda fuera del
    alcance de una web estática — te lo explico en la sección de
    seguridad más abajo.
- **Líneas del tablero visibles en PC**: el gris que separaba las
  casillas era casi invisible en algunos monitores; ahora tiene más
  contraste.
- Diseño en blanco y negro, minimalista, redondeado, con fundidos.

## Sobre la auditoría de seguridad

Me pediste un rediseño "Zero Trust" completo (RBAC con roles, JWT, CSRF,
DOMPurify, etc). Te explico exactamente qué se ha aplicado de verdad, qué
NO aplica a esta arquitectura y por qué, y qué haría falta para ir más
allá.

### 1. Lo que sí se ha implementado

**Autenticación real (Firebase Auth, sign-in anónimo)**
Antes, `userId` era un string que el propio navegador se inventaba y
guardaba en `localStorage` — cualquiera podía escribir en Firebase
haciéndose pasar por cualquier ID, porque las reglas no comprobaban nada.
Ahora cada usuario tiene un `auth.uid` real, emitido y firmado por
Firebase, verificado automáticamente por el motor de reglas en cada
lectura/escritura. Esto es lo que hace posible todo lo demás.

**Reglas de Realtime Database por usuario** (`database.rules.json`):

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "auth != null",
        ".write": "auth != null && auth.uid === $uid"
      }
    },
    "rooms": {
      ".read": "auth != null",
      "$code": {
        ".write": "auth != null && (!data.exists() || data.child('playerX/id').val() === auth.uid || data.child('playerO/id').val() === auth.uid || !data.child('playerO').exists())",
        ".validate": "newData.hasChildren(['status', 'board', 'turn'])"
      }
    }
  }
}
```

- `/users/{uid}`: **solo tú puedes escribir tu propio nodo** (`auth.uid
  === $uid`). Nadie puede modificar el nombre, la racha o la IP de otra
  persona.
- `/rooms/{code}`: solo puede escribir quien ya es `playerX` o `playerO`
  de esa sala, o alguien creando una sala nueva, o alguien uniéndose a
  una sala con el hueco de `playerO` libre. Ya no puede cualquiera
  reescribir cualquier partida ajena.
- Cualquier lectura o escritura exige `auth != null`: quien no ha iniciado
  sesión (aunque sea anónima) no puede tocar nada.

**`createRoom` con validación real de permisos** (ya en `js/rooms.js`):

```js
export async function createRoom(userId, username) {
  const code = await generateRoomCode();
  await set(ref(db, "rooms/" + code), {
    status: "waiting",
    board: emptyBoard(),
    turn: "X",
    playerX: { id: userId, name: username }, // userId = auth.uid real
    // ...
  });
  return code;
}
```

El `userId` que se guarda como dueño de la sala ya no es un dato que el
cliente se pueda inventar libremente: es el `auth.uid` que Firebase le
asignó al iniciar sesión, y las reglas del punto anterior comprueban que
coincide en cada escritura posterior. Si alguien manipulase el JavaScript
del navegador para mandar un `userId` falso, la regla `auth.uid ===
$uid` (en `/users`) o la comprobación de `playerX/id` / `playerO/id` (en
`/rooms`) lo rechazaría en el servidor de Firebase, no solo en el
cliente — que es justamente la idea de "no confiar en el cliente".

**Sanitización frente a XSS**
`main.js` construye todo con `document.createElement` + `textContent`
en vez de `innerHTML` con texto interpolado. Así, si alguien pusiera
como nombre de usuario algo como `<img src=x onerror=alert(1)>`, se
muestra literalmente como texto, no se ejecuta. No hay ningún
`innerHTML` con datos del usuario en toda la app.

**Gestión de sesión**
Al ser Firebase Auth (aunque sea anónimo), el SDK renueva el token de
sesión (ID token, un JWT real firmado por Google) automáticamente cada
hora sin que tengas que programar nada. La sesión persiste entre
visitas gracias al almacenamiento local que gestiona el propio SDK.

### 2. Lo que pediste y NO aplica tal cual a esta arquitectura (y por qué)

**RBAC con roles (`is_admin`, `role`) protegidos "solo por un admin
real"**: esto es imposible de garantizar solo con reglas de Realtime
Database, porque las reglas son lógica que corre sobre los datos, no
tienen forma de saber "quién es admin de verdad" salvo que ese dato ya
esté en algún sitio protegido — y ese sitio protegido tiene que ser
*server-side* (algo que el cliente no pueda escribir). En Firebase eso se
hace con **custom claims** puestos por el Admin SDK desde un entorno de
confianza (una Cloud Function que tú controlas, no el navegador de nadie).
Esta app es 100% estática (GitHub Pages), no tiene servidor propio, así
que no hay dónde ejecutar ese código con privilegios. Por eso la
administración (banear, borrar salas) ya no pasa por ningún panel
propio: se hace directamente desde la consola de Firebase o el CLI,
que usan tu cuenta de Google real como control de acceso — eso sí es
un control de acceso de verdad, a diferencia de una contraseña metida
en JavaScript.

**CSRF (Cross-Site Request Forgery)**: el ataque CSRF explota que un
navegador manda automáticamente las cookies de sesión de un sitio a
peticiones iniciadas desde otro sitio. Esta app **no usa cookies de
sesión** en ningún momento: el SDK de Firebase manda el token de
autenticación explícitamente en cada llamada, no depende de cookies que
el navegador adjunte solo. Por diseño, ese vector de ataque no existe
aquí de la misma forma que en una app tradicional con sesiones por
cookie. Meter "tokens CSRF" encima sería añadir complejidad sin tapar
ningún agujero real en este caso — por eso no los he implementado: sería
seguridad de cara a la galería, no seguridad real.

**Validación de esquema de peticiones POST/PUT**: no hay un backend REST
propio (no hay `POST`/`PUT` tuyos) — todo pasa por el SDK de Firebase
directamente contra Realtime Database. El equivalente real aquí son las
reglas `.validate` de `database.rules.json` (ya incluidas, comprobando
que una sala tenga `status`, `board` y `turn`). Si en el futuro añades
Cloud Functions con un endpoint HTTP propio, ahí sí aplicaría validación
de esquema clásica (con algo como Zod o Joi) del lado del servidor.

### 3. Lo que sí te recomiendo añadir si esto crece

- **Firebase App Check**: es la herramienta que Firebase ofrece
  precisamente para el problema de "inundación/DoS" que mencionas —
  verifica que las peticiones vienen de tu app real (no de un script
  automatizado golpeando tu base de datos) usando reCAPTCHA o
  attestation del dispositivo. Se activa desde la consola sin tocar
  apenas código.
- **Cloud Functions** si algún día quieres roles de verdad (admin real,
  no solo contraseña), limpieza automática de salas abandonadas por
  cron, o lógica de servidor que el cliente no deba poder manipular
  (por ejemplo, validar que una racha no se pueda falsear escribiendo
  directamente en `/users/{uid}/streak` — ah("mismo mismo problema:
  ahora mismo cualquier usuario autenticado podría, en teoría, escribir
  su propia racha a mano desde la consola del navegador, porque las
  reglas solo comprueban que escribe en *su propio* nodo, no que el
  valor sea legítimo. Cerrar esto del todo exige mover el cálculo de
  la racha a una Cloud Function que reaccione al cierre de la partida,
  en vez de dejar que el cliente la calcule).
- **Cuota de Realtime Database** y alertas de uso/facturación en la
  consola de Firebase, como red de seguridad ante un pico de escrituras
  anómalo.

### Checklist rápido para el equipo

- [ ] Nunca usar `innerHTML` con datos que vengan de otro usuario;
      usar `textContent` o `createElement`.
- [ ] Toda regla `.write` debe comprobar `auth != null` como mínimo, y
      idealmente `auth.uid` contra el dato que se está escribiendo.
- [ ] Ningún dato "de verdad sensible" (roles, resultados de partida
      oficiales, contadores que no quieras que se puedan falsear) debe
      calcularse ni validarse solo en el cliente — si hace falta que sea
      a prueba de manipulación, mover ese cálculo a una Cloud Function.
- [ ] Activar Firebase App Check antes de compartir la app públicamente
      a gran escala.
- [ ] Revisar `database.rules.json` cada vez que se añada un nodo nuevo
      a la base de datos — un nodo sin reglas explícitas puede heredar
      permisos más abiertos de lo que crees.
- [ ] Las tareas de administración (banear, borrar salas) se hacen
      desde la consola o el CLI de Firebase, nunca desde un panel
      propio con contraseña en el código — así el control de acceso
      real es tu cuenta de Google, no un secreto que viaja en el
      JavaScript.

## 1. Requisitos

- Un proyecto de [Firebase](https://console.firebase.google.com/) (ya lo tienes).
- Autenticación anónima activada (ver arriba, es nuevo y obligatorio).
- Node no hace falta: es HTML/JS estático.

## 2. Reglas de la base de datos

En la consola de Firebase, Realtime Database → pestaña **Reglas** → pega
el contenido de `database.rules.json` (incluido en este ZIP) → Publicar.

## 3. Probarlo en local

Como usa módulos de JavaScript (`type="module"`), sirve la carpeta con
Live Server (VS Code) o:

```bash
python3 -m http.server 8000
```

Y abre `http://localhost:8000`.

## 4. Desplegar en GitHub Pages

1. Sube todo el contenido de este ZIP a un repositorio de GitHub.
2. **Settings → Pages** → Deploy from a branch → rama `main` → carpeta
   `/ (root)`.
3. Tu juego estará en `https://tu-usuario.github.io/tu-repo/`.

No hay panel de administración con URL propia: toda la gestión
(banear, borrar salas, ver usuarios) se hace desde la consola o el CLI
de Firebase — ver la sección "Administración" más arriba.

## 5. Sobre el ID de usuario y la IP

- El identificador de cada usuario ya no es un ID inventado en
  `localStorage`: es el `auth.uid` de Firebase Auth (sign-in anónimo),
  verificable por las reglas de seguridad.
- La IP pública se sigue consultando a `api.ipify.org` solo para
  guardarla como dato informativo en `/users/{uid}/ip` (visible desde
  la consola de Firebase) — sigue sin ser un identificador fiable por
  sí sola (gente en la misma wifi comparte IP, una misma persona cambia
  de IP según la red). Es el `auth.uid` el que identifica de forma
  consistente.
- Guardar IPs es un dato personal: si esto lo usa gente real, ten
  presente la normativa de protección de datos que te aplique.

## 6. Estructura del proyecto

```
rayalive/
├── index.html
├── database.rules.json
├── css/
│   └── style.css
└── js/
    ├── firebase.js         Inicializa Firebase (app, db, auth)
    ├── firebase-config.js  Tus credenciales + VIP_NAME
    ├── user.js              Sesión anónima, nombre, IP informativa
    ├── ban.js                Detección de baneo (solo lectura)
    ├── vip.js                Nombre en rojo para todo el mundo
    ├── rooms.js              Salas: crear/unir/jugar/revancha/borrado
    ├── stats.js              Rachas y estadísticas por usuario
    ├── achievements.js       Definición de los logros
    ├── matchmaking.js        Buscar partida (emparejamiento automático)
    ├── ai.js                 IA con minimax
    └── main.js                Interfaz: menú, tablero, modal, temporizador
```

La administración (banear, desbanear, borrar salas, ver usuarios) no
vive en ningún archivo de este proyecto: se hace desde la consola de
Firebase o el CLI, como se explica en la sección "Administración" más
arriba.
